package com.example.veggies.domain

import io.ktor.client.*
import io.ktor.client.engine.cio.*
import io.ktor.client.features.*
import io.ktor.client.features.auth.*
import io.ktor.client.features.auth.providers.*
import io.ktor.client.features.json.*
import io.ktor.client.features.json.serializer.*
import io.ktor.client.features.logging.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat

object StkNetworkService {

    private const val clientID = "IpOAkYhhizzfwkAHP1XLNz1SNeJRvAPR"
    private const val clientSecret = "vicGTsdYHArr0AkK"
    private const val passkey = "bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919"
    private const val tokenUri = "https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials"
    private const val stkUri = "https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest"
    private const val businessShortCode = 174379
    private const val callbackUri = "https://2f0b-102-140-222-234.ngrok.io/transaction_response"

    private val tokenClient = HttpClient(CIO) {

        install(Auth) {
            basic {
                sendWithoutRequest { true }
                credentials {
                    BasicAuthCredentials(clientID, clientSecret)
                }
            }
        }

        install(Logging) {
            level = LogLevel.ALL
        }

        install(JsonFeature) {
            serializer = KotlinxSerializer(kotlinx.serialization.json.Json {
                isLenient = true
                prettyPrint = true
            })
        }
    }

    private val client = HttpClient(CIO) {

        expectSuccess = false

        engine {
            requestTimeout = 50000
        }

        defaultRequest {
            contentType(ContentType.Application.Json)
        }

        install(JsonFeature) {
            serializer = KotlinxSerializer(kotlinx.serialization.json.Json { isLenient = true; prettyPrint = true })
        }

        install(Logging) {
            level = LogLevel.ALL
        }

        install(Auth) {
            bearer {
                sendWithoutRequest { true }
                loadTokens {
                    val tokenInfo: TokenInfo = tokenClient.get(tokenUri)
                    BearerTokens(tokenInfo.access_token, "")
                }
            }
        }
    }

    private fun getFormattedTime(): String {
        val sdf = SimpleDateFormat("yyyyMMddHHmmss")
        return sdf.format(System.currentTimeMillis())
    }

    private fun getPassword(timeStamp: String): String {
        val stringToEncode = "$businessShortCode$passkey$timeStamp"
        val encoded: ByteArray = android.util.Base64.encode(stringToEncode.toByteArray(), android.util.Base64.DEFAULT)
        return String(encoded, StandardCharsets.UTF_8).replace("\n", "")
    }

    suspend fun makeStkPush(phoneNumber: Long): HttpStatusCode {
        val timeStamp = getFormattedTime()
        val password = getPassword(timeStamp)

        val response: HttpResponse = client.post(stkUri) {
            body = StkDetails(
                AccountReference = "Veggies",
                Amount = 1,
                BusinessShortCode = businessShortCode,
                CallBackURL = callbackUri,
                PartyA = 254708374149,
                PartyB = 174379,
                Password = password,
                PhoneNumber = phoneNumber,
                Timestamp = timeStamp,
                TransactionDesc = "Payment of groceries",
                TransactionType = "CustomerPayBillOnline"
            )
        }
        return response.status
    }


    @kotlinx.serialization.Serializable
    data class TokenInfo(val access_token: String, val expires_in: String)

    @kotlinx.serialization.Serializable
    data class StkDetails(
        val AccountReference: String,
        val Amount: Int,
        val BusinessShortCode: Int,
        val CallBackURL: String,
        val PartyA: Long,
        val PartyB: Int,
        val Password: String,
        val PhoneNumber: Long,
        val Timestamp: String,
        val TransactionDesc: String,
        val TransactionType: String
    )
}