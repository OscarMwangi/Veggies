package com.example.veggies.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface OrderDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(orderItem: OrderItem)

    @Query("select * from order_items")
    fun getOrders(): Flow<List<OrderItem>>

    @Query("update order_items set deliveryStatus = :newDeliveryStatus where id = :id and owner_id = :ownerId")
    suspend fun updateDeliveryStatus(id: Long, ownerId: Long, newDeliveryStatus: DeliveryStatus)
}