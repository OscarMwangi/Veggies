package com.example.veggies.signup

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.veggies.R
import com.example.veggies.databinding.FragmentAccountSetupBinding
import com.example.veggies.signup.model.SignUpViewModel
import com.github.dhaval2404.imagepicker.ImagePicker
import java.io.File


class AccountSetupFragment : Fragment() {
    private lateinit var viewModel: SignUpViewModel

    private val picturePickerResultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
            val resultCode = result.resultCode
            val data = result.data

            when (resultCode) {
                Activity.RESULT_OK -> {
                    //Image Uri will not be null for RESULT_OK
                    val fileUri = data?.data!!

                    val mProfileUri = fileUri
                    Log.e("AccountSetupFragment", "${mProfileUri.path}" )
                    viewModel.updateUserThumbnail(mProfileUri.path)
                    // send uri to viewModel--------------------------------------------------------
                }
                ImagePicker.RESULT_ERROR -> {
                    Toast.makeText(requireActivity(), ImagePicker.getError(data), Toast.LENGTH_SHORT).show()
                }
                else -> {
                    viewModel.updateUserThumbnail(null)
                    Toast.makeText(requireActivity(), "Task Cancelled", Toast.LENGTH_SHORT).show()
                }
            }
        }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding = DataBindingUtil.inflate<FragmentAccountSetupBinding>(inflater, R.layout.fragment_account_setup, container, false)
        viewModel = ViewModelProvider(requireActivity()).get(SignUpViewModel::class.java)
        binding.signUpViewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner

        viewModel.launchImagePicker.observe(viewLifecycleOwner, Observer { launch ->
            if (launch) {
                viewModel.imagePickerLaunched()
                ImagePicker.with(this)
                    .cropSquare()
                    .galleryMimeTypes(  //Exclude gif images
                        mimeTypes = arrayOf(
                            "image/png",
                            "image/jpg",
                            "image/jpeg"
                        )
                    )
                    .compress(1024)
                    //  Path: /storage/sdcard0/Android/data/package/files/Pictures/UserThumbnail
                    .saveDir(File(requireActivity().getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!, "UserThumbnail"))
                    .maxResultSize(1080, 1080)
                    .createIntent { intent ->
                        picturePickerResultLauncher.launch(intent)
                    }
            }
        })
        return binding.root
    }
}