package com.example.veggies

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.databinding.DataBindingUtil.setContentView
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import com.example.veggies.customer.CustomerActivity
import com.example.veggies.database.VeggiesDatabase
import com.example.veggies.databinding.ActivityMainBinding
import com.example.veggies.signup.model.SignUpViewModel
import com.example.veggies.signup.model.SignUpViewModelFactory
import com.example.veggies.supplier.DeliveryActivity
import com.example.veggies.vendor.VendorActivity

class MainActivity : AppCompatActivity() {
    companion object {
        private const val MODE_KEY = "mode_pref"
        private const val CUSTOMER_MODE = "customer"
        private const val VENDOR_MODE = "vendor"
        private const val SUPPLIER_MODE = "supplier"
    }

    private lateinit var CHANNELID: String
    private lateinit var signUpViewModel: SignUpViewModel
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dataSource = VeggiesDatabase.getInstance(application).userDatabaseDao
        val viewModelFactory = SignUpViewModelFactory(dataSource, application)
        signUpViewModel = ViewModelProvider(this, viewModelFactory).get(SignUpViewModel::class.java)
        binding = setContentView(this, R.layout.activity_main)
        binding.signUpViewModel = signUpViewModel
        binding.lifecycleOwner = this

        signUpViewModel.signUpComplete.observe(this) { isSignupComplete ->
            if (isSignupComplete) {
                routeToAppropriateActivity()
            }
        }

        signUpViewModel.showVerificationCodeNotification.observe(this) { show ->
            if (show) {
                signUpViewModel.verificationCodeNotificationShown()
                createNotification(signUpViewModel.notificationCode.toString())
            }
        }

        signUpViewModel.signUpComplete.observe(this) { isSignupComplete ->
            if (isSignupComplete) {
                routeToAppropriateActivity()
            }
        }

        signUpViewModel.authenticationState.observe(this) { authenticationState ->
            when (authenticationState) {
                SignUpViewModel.AuthenticationState.AUTHENTICATED -> {
                    if (!signUpViewModel.shouldSignUp) { // will always be false if user has already signed in
                        routeToAppropriateActivity()
                    }
                }
                SignUpViewModel.AuthenticationState.UNAUTHENTICATED -> {
                    signUpViewModel.shouldSignUp = true
                    findNavController(R.id.signUpNavHostFragment).setGraph(R.navigation.sign_up_navigation)
                }
            }
        }

        CHANNELID = resources.getString(R.string.notification_channel_id)
        createNotificationChannel()
    }

    private fun routeToAppropriateActivity() {
        val sharedPref = getSharedPreferences(packageName + "_preferences", Context.MODE_PRIVATE)
        when (sharedPref.getString(MODE_KEY, CUSTOMER_MODE)) {
            CUSTOMER_MODE -> {
                val intent = Intent(this, CustomerActivity::class.java)
                startActivity(intent)
                finish()
            }
            VENDOR_MODE -> {
                val intent = Intent(this, VendorActivity::class.java)
                startActivity(intent)
                finish()
            }
            SUPPLIER_MODE -> {
                val intent = Intent(this, DeliveryActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
    }

    // notification simulates verification code from network
    private fun createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = getString(R.string.notification_channel_name)
            val descriptionText = getString(R.string.notification_channel_description)
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(CHANNELID, name, importance).apply {
                description = descriptionText
            }
            // Register the channel with the system
            val notificationManager = getSystemService(
                NotificationManager::class.java
            )
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(code: String) {
        // Create an explicit intent for an Activity in your app
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent: PendingIntent = PendingIntent.getActivity(this, 0, intent, 0)

        val builder = NotificationCompat.Builder(this, CHANNELID)
            .setSmallIcon(R.drawable.ic_baseline_notifications_active_24)
            .setContentTitle("Verification code")
            .setContentText(code)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            // Set the intent that will fire when the user taps the notification
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
        with(NotificationManagerCompat.from(this)) {
            notify(0, builder.build())
        }
    }
}