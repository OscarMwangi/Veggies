package com.example.veggies

import android.widget.ImageView
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions

@BindingAdapter("imageUrl")
fun bindImage(imgView: ImageView, imgUrl: String?) {
    if (imgUrl != null) {
        Glide.with(imgView.context)
            .load(imgUrl)
            .apply(
                RequestOptions()
                    .placeholder(R.drawable.loading_animation) // loading animation
                    .error(R.drawable.ic_baseline_broken_image_24) // error image
            )
            .into(imgView)
    }
}

@BindingAdapter("drawableName")
fun bindDrawable(imgView: ImageView, drawable_name: String?) {
    if (drawable_name != null) {
        val context = imgView.context
        val drawableResourceId: Int =
            context.resources.getIdentifier(drawable_name, "drawable", context.packageName)
        Glide.with(imgView.context)
            .load(drawableResourceId)
            .apply(
                RequestOptions()
                    .placeholder(R.drawable.loading_animation) // loading animation
                    .error(R.drawable.ic_baseline_broken_image_24) // error image
            )
            .into(imgView)
    }
}