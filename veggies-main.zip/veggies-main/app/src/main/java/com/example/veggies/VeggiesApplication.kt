package com.example.veggies

import android.app.Application
import timber.log.Timber

class VeggiesApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
    }
}