package com.example.veggies.customer

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.SharedPreferences.OnSharedPreferenceChangeListener
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.example.veggies.R
import com.example.veggies.supplier.DeliveryActivity
import com.example.veggies.vendor.VendorActivity
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class CustomerActivity : AppCompatActivity() {
    companion object {
        private const val MODE_KEY = "mode_pref"
        private const val CUSTOMER_MODE = "customer"
        private const val VENDOR_MODE = "vendor"
        private const val SUPPLIER_MODE = "supplier"
    }

    private lateinit var sharedPref: SharedPreferences
    private val titleArray = arrayOf("Stores", "Cart", "History")
    private val tabIcons = intArrayOf(
        R.drawable.ic_baseline_storefront_24,
        R.drawable.ic_baseline_shopping_cart_24,
        R.drawable.ic_baseline_history_24
    )
    private lateinit var tabLayout: TabLayout
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_customer)
        sharedPref = getSharedPreferences(packageName + "_preferences", Context.MODE_PRIVATE)
        sharedPref.registerOnSharedPreferenceChangeListener(sharedPreferenceChangeListener)
        val viewPager = findViewById<ViewPager2>(R.id.pager)
        tabLayout = findViewById(R.id.tab_layout)

        val adapter = CustomerViewPagerAdapter(this)

        viewPager.adapter = adapter
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = titleArray[position]
        }.attach()
        setupTabIcons()
    }

    private fun setupTabIcons() {
        tabLayout.getTabAt(0)?.setIcon(tabIcons[0])
        tabLayout.getTabAt(1)?.setIcon(tabIcons[1])
        tabLayout.getTabAt(2)?.setIcon(tabIcons[2])
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_customer_mode -> {
                // do nothing, already in customer mode
                true
            }
            R.id.action_vendor_mode -> {
                with(sharedPref.edit()) {
                    putString(MODE_KEY, VENDOR_MODE)
                    apply()
                }
                true
            }

            R.id.action_supplier_mode -> {
                with(sharedPref.edit()) {
                    putString(MODE_KEY, SUPPLIER_MODE)
                    apply()
                }
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private val sharedPreferenceChangeListener =
        OnSharedPreferenceChangeListener { _, key ->
            if (key == MODE_KEY) {
                when (sharedPref.getString(MODE_KEY, CUSTOMER_MODE)) {
                    VENDOR_MODE -> {
                        val intent = Intent(this, VendorActivity::class.java)
                        startActivity(intent)
                        finish()
                    }
                    SUPPLIER_MODE -> {
                        val intent = Intent(this, DeliveryActivity::class.java)
                        startActivity(intent)
                        finish()
                    }
                }
            }
        }
}