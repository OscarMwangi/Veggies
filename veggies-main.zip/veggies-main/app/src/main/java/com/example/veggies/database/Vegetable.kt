package com.example.veggies.database

import androidx.annotation.NonNull
import androidx.room.ColumnInfo
import androidx.room.Entity

@Entity(tableName = "vegetables", primaryKeys = ["id", "owner_id"])
data class Vegetable(
    @NonNull
    val id: Long,
    @ColumnInfo(name = "owner_id")
    @NonNull
    val owner_id: Long,
    @NonNull
    val name: String,
    @NonNull
    val currency: String,
    @NonNull
    val price: Int,
    @NonNull
    val quantity: Long = 0L,
    @NonNull
    val thumbnail: String,
)

@Entity(tableName = "cart_vegetables", primaryKeys = ["id", "owner_id"])
data class CartVegetable(
    @NonNull
    val id: Long,
    @ColumnInfo(name = "owner_id")
    @NonNull
    val owner_id: Long,
    @NonNull
    val name: String,
    @NonNull
    val currency: String,
    @NonNull
    val price: Int,
    @NonNull
    val quantity: Long = 0L,
    @NonNull
    val thumbnail: String,
)

fun CartVegetable.toOrderItem(): OrderItem {
    return OrderItem(
        id = id,
        owner_id = owner_id,
        name = name,
        currency = currency,
        price = price,
        quantity = quantity,
        thumbnail = thumbnail,
        deliveryStatus = DeliveryStatus.PENDING
    )
}


fun CartVegetable.toPurchasedItem(): PurchasedItem {
    return PurchasedItem(
        id = id,
        owner_id = owner_id,
        name = name,
        currency = currency,
        price = price,
        quantity = quantity,
        thumbnail = thumbnail,
    )
}

@Entity(tableName = "order_items", primaryKeys = ["id", "owner_id"])
data class OrderItem(
    @NonNull
    val id: Long,
    @ColumnInfo(name = "owner_id")
    @NonNull
    val owner_id: Long,
    @NonNull
    val name: String,
    @NonNull
    val currency: String,
    @NonNull
    val price: Int,
    @NonNull
    val quantity: Long = 0L,
    @NonNull
    val thumbnail: String,
    @NonNull
    val deliveryStatus: DeliveryStatus
)

@Entity(tableName = "purchase_items", primaryKeys = ["id", "owner_id"])
data class PurchasedItem(
    @NonNull
    val id: Long,
    @ColumnInfo(name = "owner_id")
    @NonNull
    val owner_id: Long,
    @NonNull
    val name: String,
    @NonNull
    val currency: String,
    @NonNull
    val price: Int,
    @NonNull
    val quantity: Long = 0L,
    @NonNull
    val thumbnail: String,
)


enum class DeliveryStatus { PENDING, DISPATCHED, INTRANS, DELIVERED }

fun DeliveryStatus.toFloat(): Float {
    return when (this) {
        DeliveryStatus.PENDING -> .25f
        DeliveryStatus.DISPATCHED -> .5f
        DeliveryStatus.INTRANS -> .75f
        DeliveryStatus.DELIVERED -> 1f
    }
}