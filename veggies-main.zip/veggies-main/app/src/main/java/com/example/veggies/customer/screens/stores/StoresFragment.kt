package com.example.veggies.customer.screens.stores

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.veggies.R
import com.example.veggies.customer.screens.store.StoreActivity
import com.example.veggies.customer.screens.stores.model.StoresViewModel
import com.example.veggies.customer.screens.stores.model.StoresViewModelFactory
import com.example.veggies.database.VeggiesDatabase
import com.example.veggies.databinding.FragmentStoresBinding


class StoresFragment : Fragment() {
    companion object {
        @JvmStatic
        fun newInstance() = StoresFragment()
    }

    private val storeResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { /* ignore*/ }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        // Inflate the layout for this fragment
        val binding: FragmentStoresBinding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_stores, container, false)
        val dataSource = VeggiesDatabase.getInstance(requireContext()).storeDatabaseDao
        val application = requireNotNull(this.activity).application
        val viewModelFactory = StoresViewModelFactory(dataSource, application)
        val storesViewModel = ViewModelProvider(this, viewModelFactory)[StoresViewModel::class.java]
        binding.storesViewModel = storesViewModel
        val adapter = StoresAdapter(StoresListener {
            val intent = Intent(this.context, StoreActivity::class.java)
            intent.putExtra(StoreActivity.EXTRA_STORE_ID, it)
            storeResultLauncher.launch(intent)
        })
        binding.storesList.adapter = adapter
        storesViewModel.stores.observe(viewLifecycleOwner) {
            it?.let { adapter.submitList(it) }
        }
        binding.lifecycleOwner = this
        return binding.root
    }
}