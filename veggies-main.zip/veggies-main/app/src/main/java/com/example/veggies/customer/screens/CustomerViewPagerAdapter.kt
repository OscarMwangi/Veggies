package com.example.veggies.customer.screens

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter

class CustomerViewPagerAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {
    private val ITEM_COUNT = 2
    override fun getItemCount(): Int {
        return ITEM_COUNT
    }

    override fun createFragment(position: Int): Fragment = when (position) {
        0 -> StoreFragment.newInstance()
        1 -> CartFragment.newInstance()
        else -> StoreFragment.newInstance()
    }
}