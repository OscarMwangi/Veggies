package com.example.veggies.customer

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.veggies.customer.screens.cart.CartFragment
import com.example.veggies.customer.screens.purchaseHistory.PurchaseHistoryFragment
import com.example.veggies.customer.screens.stores.StoresFragment

class CustomerViewPagerAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {

    override fun getItemCount(): Int {
        return 3
    }

    override fun createFragment(position: Int): Fragment = when (position) {
        0 -> StoresFragment.newInstance()
        1 -> CartFragment.newInstance()
        2 -> PurchaseHistoryFragment.newInstance()
        else -> StoresFragment.newInstance()
    }
}