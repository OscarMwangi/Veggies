package com.example.veggies.customer.screens.purchaseHistory

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.Card
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.unit.dp
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.veggies.compose.components.ImageView
import com.example.veggies.database.PurchasedItem
import com.example.veggies.database.VeggiesDatabase
import com.example.veggies.getResourceFromString

class PurchaseHistoryFragment : Fragment() {

    companion object {
        @JvmStatic
        fun newInstance() = PurchaseHistoryFragment()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val database = VeggiesDatabase.getInstance(requireContext())
        val viewModelFactory = PurchaseHistoryViewModelFactory(database)
        val viewModel = ViewModelProvider(this, viewModelFactory)[PurchaseHistoryViewModel::class.java]

        return ComposeView(requireContext()).apply {
            setContent {
                PurchaseHistoryScreen(viewModel)
            }
        }
    }
}

@Composable
fun PurchaseHistoryScreen(viewModel: PurchaseHistoryViewModel) {

    val purchasedItems = viewModel.purchaseHistory.collectAsState(listOf())

    if (purchasedItems.value.isEmpty()) Text(
        text = "No purchases made yet",
        style = MaterialTheme.typography.body1,
        color = Color.Black, modifier = Modifier
            .padding(30.dp)
            .fillMaxWidth()
    )

    LazyColumn {
        items(purchasedItems.value) { purchasedItem ->
            PurchaseItem(purchasedItem)
        }
    }
}

@Composable
fun PurchaseItem(purchasedItem: PurchasedItem) {
    Card(
        modifier = Modifier
            .padding(8.dp)
            .fillMaxWidth(),
        elevation = 8.dp
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            ImageView(imageRes = getResourceFromString(purchasedItem.thumbnail), size = 100.dp)

            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                Text(text = "Item : ${purchasedItem.name}", color = Color.Gray)
                Text(text = "Purchased quantity : ${purchasedItem.quantity}", color = Color.Gray)
                Text(text = "Total Paid : ${purchasedItem.price * purchasedItem.quantity}", color = Color.Gray)
            }
        }
    }
}