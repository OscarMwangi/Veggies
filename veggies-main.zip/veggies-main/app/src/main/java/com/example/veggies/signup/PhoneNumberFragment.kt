package com.example.veggies.signup

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.veggies.R
import com.example.veggies.databinding.FragmentPhoneNumberBinding
import com.example.veggies.signup.model.SignUpViewModel
import timber.log.Timber


class PhoneNumberFragment : Fragment() {
    private lateinit var viewModel: SignUpViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val binding = DataBindingUtil.inflate<FragmentPhoneNumberBinding>(inflater, R.layout.fragment_phone_number, container,false)
        viewModel = ViewModelProvider(requireActivity()).get(SignUpViewModel::class.java)
        binding.signUpViewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner
        val inputMethodManager =
            context?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        viewModel.isProgressBarShown.observe(viewLifecycleOwner, Observer { isShown ->
            Timber.e("isProgressBarShown: $isShown")
            if (isShown) {
                binding.phone.clearFocus()
                inputMethodManager.hideSoftInputFromWindow(binding.phone.windowToken, 0)
            } else {
                binding.phone.focusAndShowKeyboard()
            }
        })
        viewModel.onPhoneNumberSubmitted.observe(viewLifecycleOwner, Observer { submitted ->
            if (submitted) {
                findNavController().navigate(R.id.action_phoneNumberFragment_to_OTPFragment)
            }
        })
        return binding.root
    }
}