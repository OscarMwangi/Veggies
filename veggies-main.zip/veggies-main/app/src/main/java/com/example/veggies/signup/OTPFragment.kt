package com.example.veggies.signup

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import androidx.activity.result.contract.ActivityResultContracts
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.veggies.R
import com.example.veggies.databinding.FragmentOTPBinding
import com.example.veggies.signup.model.SignUpViewModel

class OTPFragment : Fragment() {
    private lateinit var viewModel: SignUpViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val binding = DataBindingUtil.inflate<FragmentOTPBinding>(inflater, R.layout.fragment_o_t_p, container, false)
        viewModel = ViewModelProvider(requireActivity()).get(SignUpViewModel::class.java)
        binding.signUpViewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner
        val inputMethodManager =
            context?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        viewModel.isProgressBarShown.observe(viewLifecycleOwner, Observer { isShown ->
            if (isShown) {
                binding.otpEditText.clearFocus()
                inputMethodManager.hideSoftInputFromWindow(binding.submit.windowToken, 0)
            } else {
                binding.otpEditText.focusAndShowKeyboard()
            }
        })
        viewModel.onCodeSubmitted.observe(viewLifecycleOwner, Observer { submitted ->
            if (submitted) {
                findNavController().navigate(R.id.action_OTPFragment_to_accountSetupFragment)
            }
        })

        return binding.root
    }



}