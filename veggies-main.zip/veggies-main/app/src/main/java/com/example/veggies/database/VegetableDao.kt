package com.example.veggies.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface VegetableDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(vegetable: Vegetable): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(list: List<Vegetable>)

    @Query("SELECT * FROM vegetables WHERE owner_id =:key ORDER BY id ASC")
    fun getStoreVegetables(key: Long): LiveData<List<Vegetable>>
}