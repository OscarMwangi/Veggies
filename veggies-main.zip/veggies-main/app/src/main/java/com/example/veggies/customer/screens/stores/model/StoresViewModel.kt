package com.example.veggies.customer.screens.stores.model

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.example.veggies.database.Store
import com.example.veggies.database.StoreDao


class StoresViewModel(val database: StoreDao, application: Application) : AndroidViewModel(application) {
    private val _stores = database.getAllStores()
    val stores: LiveData<List<Store>>
        get() = _stores
}