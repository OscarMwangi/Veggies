package com.example.veggies.customer.screens.store.model

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.veggies.database.VeggiesDatabase

class StoreStockViewModelFactory(
    private val database: VeggiesDatabase,
    private val storeId: Long,
    private val application: Application
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(StoreStockViewModel::class.java)) {
            return StoreStockViewModel(database, storeId, application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}