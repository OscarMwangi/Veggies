package com.example.veggies.customer.screens.cart

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.veggies.database.CartVegetable
import com.example.veggies.database.VeggiesDatabase
import com.example.veggies.database.toOrderItem
import com.example.veggies.database.toPurchasedItem
import com.example.veggies.domain.StkNetworkService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch


class CartViewModel(val database: VeggiesDatabase) : ViewModel() {

    private val _cartItems: Flow<List<CartVegetable>> = database.userDatabaseDao.getCartItems()
    val cartItems: Flow<List<CartVegetable>> get() = _cartItems

    var isPaymentLoading by mutableStateOf(false)

    fun updateCartItemQuantity(cartVegetable: CartVegetable, newQuantity: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            if (newQuantity < 1) {
                database.userDatabaseDao.deleteCartItem(cartVegetable.id, cartVegetable.owner_id)
            } else {
                database.userDatabaseDao.updateCartItem(
                    cartVegetable.id,
                    cartVegetable.owner_id,
                    newQuantity
                )

            }
        }
    }

    private fun loadPayment(cartItems: List<CartVegetable>) {
        viewModelScope.launch {
            isPaymentLoading = true
            delay(10000)
            isPaymentLoading = false
            updateOrders(cartItems)
            addToPurchaseHistory(cartItems)
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    fun makeStkPush(cartItems: List<CartVegetable>) {
        viewModelScope.launch(Dispatchers.IO) {
            database.userDatabaseDao.getUserFlow(1L).collect { user ->
                val number = user.phoneNumber.toLong()
                StkNetworkService.makeStkPush(number)
                loadPayment(cartItems)
            }
        }
    }

    private fun updateOrders(cartItems: List<CartVegetable>) {
        viewModelScope.launch(Dispatchers.IO) {
            cartItems.forEach { cartVegetable ->
                database.orderDao.insertOrder(cartVegetable.toOrderItem())
            }
            database.userDatabaseDao.deleteAllCartItems()
        }
    }

    private fun addToPurchaseHistory(cartItems: List<CartVegetable>) {
        viewModelScope.launch(Dispatchers.IO) {
            cartItems.forEach { cartVegetable ->
                database.userDatabaseDao.insertToUserPurchaseHistory(cartVegetable.toPurchasedItem())
            }
        }
    }
}

@Suppress("UNCHECKED_CAST")
class CartViewModelFactory(val database: VeggiesDatabase) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CartViewModel::class.java)) {
            return CartViewModel(database) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}