package com.example.veggies.customer.screens.store.model

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.viewModelScope
import com.example.veggies.database.CartVegetable
import com.example.veggies.database.Store
import com.example.veggies.database.Vegetable
import com.example.veggies.database.VeggiesDatabase
import kotlinx.coroutines.launch

class StoreStockViewModel(val database: VeggiesDatabase, storeId: Long, application: Application) :
    AndroidViewModel(application) {
    private val _stock = database.vegetableDatabaseDao.getStoreVegetables(storeId)
    val stock: LiveData<List<Vegetable>> get() = _stock
    private var _store = database.storeDatabaseDao.getStore(storeId)
    val store: LiveData<Store> get() = _store
    private val _user = database.userDatabaseDao.getUser(1L)
    val cart = Transformations.map(_user) { it.cart }

    fun addToCart(cartVegetable: CartVegetable) {
        viewModelScope.launch {
            database.userDatabaseDao.addToCart(cartVegetable)
        }
    }
}