package com.example.veggies.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import okio.buffer
import okio.source
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.nio.charset.Charset

@Database(
    entities = [User::class, Store::class, Vegetable::class, CartVegetable::class, OrderItem::class, PurchasedItem::class],
    version = 12,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class VeggiesDatabase : RoomDatabase() {
    abstract val userDatabaseDao: UserDao
    abstract val storeDatabaseDao: StoreDao
    abstract val vegetableDatabaseDao: VegetableDao
    abstract val orderDao: OrderDao

    companion object {
        @Volatile
        private var INSTANCE: VeggiesDatabase? = null
        fun getInstance(context: Context): VeggiesDatabase {
            synchronized(this) {
                var instance = INSTANCE
                if (instance == null) {
                    instance = Room.databaseBuilder(
                        context.applicationContext,
                        VeggiesDatabase::class.java,
                        "veggies_database"
                    )
                        .addCallback(VeggiesDatabaseCallback(context))
                        .fallbackToDestructiveMigration()
                        .build()
                    INSTANCE = instance
                }
                return instance
            }
        }

        private class VeggiesDatabaseCallback(private val context: Context) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    val scope = CoroutineScope(Job() + Dispatchers.IO)
                    scope.launch {
                        prepopulateDb(context, database)
                    }
                }
            }
        }

        private suspend fun prepopulateDb(context: Context, db: VeggiesDatabase) {
            try {
                val storesObject = JSONObject(readJsonFromAssets(context, "stores.json")!!)
                val storesJSONArray: JSONArray = storesObject.getJSONArray("stores")
                val storesList: ArrayList<Store> = arrayListOf()
                for (i in 0 until storesJSONArray.length()) {
                    val storeObject = storesJSONArray.getJSONObject(i)
                    val store: Store = Gson().fromJson(storeObject.toString(), Store::class.java)
                    storesList.add(store)
                }
                db.storeDatabaseDao.insertAll(storesList)

                val stocksObject = JSONObject(readJsonFromAssets(context, "stocks.json")!!)
                val stocksJSONArray: JSONArray = stocksObject.getJSONArray("stocks")
                val vegetableList: ArrayList<Vegetable> = arrayListOf()
                for (i in 0 until stocksJSONArray.length()) {
                    val vegetableObject = stocksJSONArray.getJSONObject(i)
                    val vegetable: Vegetable = Gson().fromJson(vegetableObject.toString(), Vegetable::class.java)
                    vegetableList.add(vegetable)
                }
                db.vegetableDatabaseDao.insertAll(vegetableList)
            } catch (e: JSONException) {
                e.printStackTrace()
            }
        }

        private fun readJsonFromAssets(context: Context, filePath: String): String? {
            try {
                val source = context.assets.open(filePath).source().buffer()
                return source.readByteString().string(Charset.forName("utf-8"))
            } catch (e: IOException) {
                e.printStackTrace()
            }
            return null
        }
    }

}