package com.example.veggies.customer.screens.stores

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.veggies.database.Store
import com.example.veggies.databinding.StoreItemViewBinding

class StoresAdapter(private val clickListener: StoresListener) : ListAdapter<Store, StoresAdapter.ViewHolder>(StoresDiffCallback()) {

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position), clickListener)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
      return ViewHolder.from(parent)
    }

    class ViewHolder private constructor(private val binding: StoreItemViewBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: Store, clickListener: StoresListener) {
            binding.store = item
            binding.clickListener = clickListener
            binding.executePendingBindings()
        }

        companion object {
            fun from(parent: ViewGroup): ViewHolder {
                val layoutInflater = LayoutInflater.from(parent.context)
                val binding = StoreItemViewBinding.inflate(layoutInflater, parent, false)
                return ViewHolder(binding)
            }
        }
    }
}

class StoresDiffCallback : DiffUtil.ItemCallback<Store>() {
    override fun areContentsTheSame(oldItem: Store, newItem: Store): Boolean {
        return oldItem == newItem
    }

    override fun areItemsTheSame(oldItem: Store, newItem: Store): Boolean {
        return oldItem.id == newItem.id
    }
}

class StoresListener(val clickListener: (id: Long) -> Unit) {
    fun onClick(store: Store) =  clickListener(store.id)
}