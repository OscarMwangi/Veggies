package com.example.veggies.database

import androidx.annotation.NonNull
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stores")
data class Store(
    @PrimaryKey
    @NonNull
    val id: Long,
    @NonNull
    val name: String,
    @NonNull
    val phone: String,
    @NonNull
    val address: String,
    @NonNull
    val distance: Float,
    @NonNull
    val open: Map<String, String>,
    val thumbnail: String,
)