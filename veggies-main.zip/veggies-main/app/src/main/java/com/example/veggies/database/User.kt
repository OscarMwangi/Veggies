package com.example.veggies.database

import androidx.annotation.NonNull
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = false)
    @ColumnInfo(name = "user_id")
    @NonNull
    val userId: Long,
    @ColumnInfo(name = "phone_number")
    @NonNull
    val phoneNumber: String,
    @ColumnInfo(name = "user_name")
    val userName: String? = null,
    val thumbnail: String? = null,
    val cart: List<Long> = emptyList(),
)