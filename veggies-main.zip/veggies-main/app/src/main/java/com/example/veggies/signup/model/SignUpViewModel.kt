package com.example.veggies.signup.model

import android.app.Application
import android.content.Context
import android.os.CountDownTimer
import android.text.format.DateUtils
import androidx.lifecycle.*
import com.example.veggies.R
import com.example.veggies.database.User
import com.example.veggies.database.UserDao
import com.google.i18n.phonenumbers.NumberParseException
import com.google.i18n.phonenumbers.PhoneNumberUtil
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SignUpViewModel(private val database: UserDao, application: Application) :
    AndroidViewModel(application) {
    private val sharedPref = application.getSharedPreferences(
        application.packageName + "_preferences",
        Context.MODE_PRIVATE
    )

    private val phoneNumberUtil = PhoneNumberUtil.getInstance()

    // hold number entered in phone number edit text
    val phoneNumber = MutableLiveData<String>()

    // hold phone number validation error string
    val phoneNumberError = MutableLiveData<Int?>()

    private val _isProgressBarShown = MutableLiveData<Boolean>()
    val isProgressBarShown: LiveData<Boolean>
        get() = _isProgressBarShown

    private var _verificationCode: MutableLiveData<Int> = MutableLiveData()
    val verificationCode = Transformations.map(_verificationCode) { code ->
        code?.toString() ?: ""
    }

    var notificationCode: Long = 0L

    private val _showVerificationCodeNotification = MutableLiveData<Boolean>()
    val showVerificationCodeNotification: LiveData<Boolean>
        get() = _showVerificationCodeNotification

    fun verificationCodeNotificationShown() {
        _showVerificationCodeNotification.value = false
    }

    private val _verificationCodeError = MutableLiveData<String>()
    val verificationCodeError: LiveData<String>
        get() = _verificationCodeError

    private val _isVerificationCodeExpired = MutableLiveData<Boolean>()
    val isVerificationCodeExpired: LiveData<Boolean>
        get() = _isVerificationCodeExpired

    private val _onCodeSubmitted = MutableLiveData<Boolean>()
    val onCodeSubmitted: LiveData<Boolean>
        get() = _onCodeSubmitted

    private val _onPhoneNumberSubmitted = MutableLiveData<Boolean>()
    val onPhoneNumberSubmitted: LiveData<Boolean>
        get() = _onPhoneNumberSubmitted

    companion object {
        // Time when the verification code is expired
        private const val DONE = 0L

        // Countdown time interval
        private const val ONE_SECOND = 1000L

        // Total time for verification code validity
        private const val COUNTDOWN_TIME = 60000L

        private const val MODE_KEY = "mode_pref"
        private const val CUSTOMER_MODE = "customer"
        private const val VENDOR_MODE = "vendor"
        private const val SUPPLIER_MODE = "supplier"
    }

    private lateinit var timer: CountDownTimer

    // Countdown time
    private val _currentTime = MutableLiveData<Long>()
    private val currentTime: LiveData<Long>
        get() = _currentTime

    // The String version of the current time
    val currentTimeString = Transformations.map(currentTime) { time ->
        DateUtils.formatElapsedTime(time)
    }

    // Sign up needed
    var shouldSignUp: Boolean = false

    private val _user = database.getUser(1L)
    private val user: LiveData<User>
    get() = _user

    enum class AuthenticationState {
        AUTHENTICATED, UNAUTHENTICATED
    }

    val authenticationState = Transformations.map(user) { user ->
        if (user != null) {
            AuthenticationState.AUTHENTICATED
        } else {
            AuthenticationState.UNAUTHENTICATED
        }
    }

    val thumbnail = Transformations.map(user) { user ->
        user?.thumbnail
    }

    val userName: MutableLiveData<String> = MutableLiveData()

    private val _signUpComplete = MutableLiveData<Boolean>()
    val signUpComplete: LiveData<Boolean>
        get() = _signUpComplete

    private val _launchImagePicker: MutableLiveData<Boolean> = MutableLiveData()
    val launchImagePicker: LiveData<Boolean>
        get() = _launchImagePicker

    private val _customerIsChecked: MutableLiveData<Boolean> = MutableLiveData()
    val customerIsChecked: LiveData<Boolean>
        get() = _customerIsChecked

    private val _vendorIsChecked: MutableLiveData<Boolean> = MutableLiveData()
    val vendorIsChecked: LiveData<Boolean>
        get() = _vendorIsChecked

    private val _supplierIsChecked: MutableLiveData<Boolean> = MutableLiveData()
    val supplierIsChecked: LiveData<Boolean>
        get() = _supplierIsChecked

    init {
        phoneNumber.value = "+254"
        _isProgressBarShown.value = false
        when (sharedPref.getString(MODE_KEY, null)) {
            null -> {
                _customerIsChecked.value = true
                with(sharedPref.edit()) {
                    putString(MODE_KEY, CUSTOMER_MODE)
                    apply()
                }
            }
            CUSTOMER_MODE -> {
                _customerIsChecked.value = true
            }
            VENDOR_MODE -> {
                _vendorIsChecked.value = true
            }
            SUPPLIER_MODE -> {
                _supplierIsChecked.value = true
            }
        }
    }

    fun updateUserThumbnail(url: String?) {
        viewModelScope.launch {
            database.updateUserThumbnail(1L, url)
        }
    }

    fun verifyPhoneNumber() {
        if (phoneNumber.value.isNullOrEmpty()) {
            phoneNumberError.value = R.string.contact_error
        } else {
            try {
                val numberProto = phoneNumberUtil.parse(phoneNumber.value, "")
                val isValid = phoneNumberUtil.isValidNumber(numberProto)
                if (isValid) {
                    // simulate network delay
                    viewModelScope.launch {
                        _isProgressBarShown.value = true
                        delay(2000)
                        // route to verification code fragment
                        _isProgressBarShown.value = false
                        _onPhoneNumberSubmitted.value = true
                        generateVerificationCode()
                    }
                } else {
                    phoneNumberError.value = R.string.contact_error
                }
            } catch (e: NumberParseException) {
                phoneNumberError.value = R.string.contact_error
            }
        }
    }

    private fun startTimer() {
        timer = object : CountDownTimer(COUNTDOWN_TIME, ONE_SECOND) {

            override fun onTick(millisUntilFinished: Long) {
                _currentTime.value = millisUntilFinished / ONE_SECOND
            }

            override fun onFinish() {
                _isVerificationCodeExpired.value = true
                _currentTime.value = DONE
                _verificationCode.value = null
            }
        }
        timer.start()
    }

    fun submitVerificationCode() {
        if (verificationCode.value.isNullOrEmpty()) {
            _verificationCodeError.value = "Enter a valid 6 digit code"
        } else {
            if (verificationCode.value!!.length != 6) {
                _verificationCodeError.value = "Enter a valid 6 digit code"
            } else {
                if (_currentTime.value == DONE) { // verification code expired
                    _verificationCodeError.value =
                        "Verification code expired, click resend to request a new code"
                } else { // submit code
                    timer.cancel()
                    _isProgressBarShown.value = true
                    insertUser()
                }
            }
        }
    }

    private fun insertUser() {
        viewModelScope.launch {
            phoneNumber.value?.let { User(userId = 1L, phoneNumber = it) }?.let { insert(it) }
            _onCodeSubmitted.value = true
            _isProgressBarShown.value = false
        }
    }

    private suspend fun insert(user: User) {
        database.insert(user)
    }

    fun resendVerificationCode() {
        generateVerificationCode()
    }

    private fun generateVerificationCode() {
        _isVerificationCodeExpired.value = false
        val code = (345758..784639).random()
        notificationCode = code.toLong()
        // show a notification
        _showVerificationCodeNotification.value = true
        startTimer()
        getVerificationCode(code)
    }

    private fun getVerificationCode(code: Int) {
        viewModelScope.launch {
            delay(3000)
            _verificationCode.value = code
            delay(100)
            timer.cancel()
            _isProgressBarShown.value = true
            insertUser()
        }
    }

    fun onImageClick() {
        _launchImagePicker.value = true
    }

    fun imagePickerLaunched() {
        _launchImagePicker.value = false
    }

    fun onCustomerClick() {
        _customerIsChecked.value = true
        _vendorIsChecked.value = false
        _supplierIsChecked.value = false
        with(sharedPref.edit()) {
            putString(MODE_KEY, CUSTOMER_MODE)
            apply()
        }
    }

    fun onVendorClick() {
        _customerIsChecked.value = false
        _vendorIsChecked.value = true
        _supplierIsChecked.value = false
        with(sharedPref.edit()) {
            putString(MODE_KEY, VENDOR_MODE)
            apply()
        }
    }

    fun onSupplierClick() {
        _customerIsChecked.value = false
        _vendorIsChecked.value = false
        _supplierIsChecked.value = true
        with(sharedPref.edit()) {
            putString(MODE_KEY, SUPPLIER_MODE)
            apply()
        }
    }

    fun onLooksGoodClick() {
        _isProgressBarShown.value = true
        viewModelScope.launch {
            database.updateUserName(1L, userName.value)
            _signUpComplete.value = true
        }
    }

    override fun onCleared() {
        super.onCleared()
        if (::timer.isInitialized)
            timer.cancel()
    }
}