package com.example.veggies.compose.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.Card
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.LinearProgressIndicator
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import com.example.veggies.database.OrderItem
import com.example.veggies.database.toFloat
import com.example.veggies.getResourceFromString

@Composable
fun RowScope.SpaceAbsolute() {
    Spacer(modifier = Modifier.weight(1f))
}

@Composable
fun ColumnScope.SpaceAbsolute() {
    Spacer(modifier = Modifier.weight(1f))
}

@Composable
fun ImageView(imageRes: Int, size: Dp) {
    SubcomposeAsyncImage(
        model = imageRes,
        contentDescription = "",
        modifier = Modifier.size(size),
        loading = { CircularProgressIndicator() },
        contentScale = ContentScale.Crop
    )
}

@Composable
fun OrderItem(orderItem: OrderItem, onclick: () -> Unit = {}) {
    Card(modifier = Modifier.padding(4.dp), elevation = 8.dp) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ImageView(imageRes = getResourceFromString(orderItem.thumbnail), 120.dp)


            Column(modifier = Modifier.padding(horizontal = 8.dp)) {

                Text(text = "Item : ${orderItem.name}", color = Color.Gray)
                Text(text = "Ordered quantity : ${orderItem.quantity}", color = Color.Gray)

                Spacer(modifier = Modifier.height(16.dp))

                Text(text = "Progress : ${orderItem.deliveryStatus.toString().lowercase()}", color = Color.Gray)

                LinearProgressIndicator(
                    orderItem.deliveryStatus.toFloat(),
                    modifier = Modifier
                        .padding(vertical = 4.dp)
                        .height(6.dp)
                        .fillMaxWidth()
                        .clip(CircleShape), color = Color(0XFF319260)
                )
            }
        }
    }
}

