package com.example.veggies.customer.screens.cart

import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.veggies.R
import com.example.veggies.compose.components.ImageView
import com.example.veggies.compose.components.SpaceAbsolute
import com.example.veggies.database.CartVegetable
import com.example.veggies.database.VeggiesDatabase
import com.example.veggies.getResourceFromString
import com.example.veggies.toast


class CartFragment : Fragment() {
    companion object {
        @JvmStatic
        fun newInstance() = CartFragment()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {

        val database = VeggiesDatabase.getInstance(requireContext())
        val cartViewModelFactory = CartViewModelFactory(database)
        val cartViewModel = ViewModelProvider(requireActivity(), cartViewModelFactory)[CartViewModel::class.java]

        return ComposeView(requireContext()).also {
            it.setContent {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) { Content(cartViewModel) }
            }
        }
    }
}

@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun Content(viewModel: CartViewModel) {
    val cartItems: State<List<CartVegetable>> = viewModel.cartItems.collectAsState(listOf())
    val grandTotal = cartItems.value.sumOf { it.price * it.quantity }
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = { CartBottomBar(gradTotal = grandTotal, viewModel = viewModel, cartItems = cartItems.value) }) {
        Cart(viewModel = viewModel, cartItems)
    }
}

@Composable
fun Cart(viewModel: CartViewModel, cartItems: State<List<CartVegetable>>) {

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(cartItems.value) { veg ->
            CartItem(cartVegetable = veg, viewModel = viewModel)
        }
    }
    if (viewModel.isPaymentLoading) Loading()
}

@Composable
fun CartItem(cartVegetable: CartVegetable, viewModel: CartViewModel) {
    Card(
        modifier = Modifier
            .padding(4.dp)
            .fillMaxWidth(), elevation = 8.dp
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ImageView(imageRes = getResourceFromString(cartVegetable.thumbnail), size = 80.dp)
            Column(
                modifier = Modifier.padding(8.dp)
            ) {
                Text(text = "Item : ${cartVegetable.name}", color = Color.Gray)
                Text(text = "Price : ${cartVegetable.price} ${cartVegetable.currency}", color = Color.Gray)
                Text(
                    text = "Total : ${cartVegetable.price * cartVegetable.quantity} ${cartVegetable.currency}",
                    color = Color.Gray
                )
            }
            SpaceAbsolute()
            IconButton(onClick = { viewModel.updateCartItemQuantity(cartVegetable, cartVegetable.quantity - 1) }) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_baseline_remove_circle_outline_24),
                    contentDescription = "Add more to cart", tint = Color.Gray
                )
            }
            Text(
                text = cartVegetable.quantity.toString(),
                modifier = Modifier.padding(horizontal = 8.dp),
                color = Color.Gray
            )
            IconButton(onClick = { viewModel.updateCartItemQuantity(cartVegetable, cartVegetable.quantity + 1) }) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_baseline_add_circle_outline_24),
                    contentDescription = "Remove from cart", tint = Color.Gray
                )
            }
        }

    }
}


@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun CartBottomBar(gradTotal: Long, viewModel: CartViewModel, cartItems: List<CartVegetable>) {
    val context = LocalContext.current as ComponentActivity
    BottomAppBar(backgroundColor = Color(0XFF319260)) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Grand Total : $gradTotal Ksh",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = Color.White
            )
            SpaceAbsolute()
            TextButton(onClick = {
                if (gradTotal < 1) {
                    context.toast("please add items to cart first")
                } else {
                    viewModel.makeStkPush(cartItems)
                }
            }) {
                Text(text = "Checkout", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
fun Loading() {
    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Spacer(modifier = Modifier.height(50.dp))
            Card(
                elevation = 20.dp,
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape),
                backgroundColor = Color.White
            ) {
                CircularProgressIndicator(modifier = Modifier.padding(20.dp), color = Color(0XFF319260))
            }
        }
    }
}