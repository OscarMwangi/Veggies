package com.example.veggies.supplier

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import com.example.veggies.R
import com.example.veggies.compose.components.ImageView
import com.example.veggies.compose.theme.VeggiesTheme
import com.example.veggies.customer.CustomerActivity
import com.example.veggies.database.OrderItem
import com.example.veggies.database.VeggiesDatabase
import com.example.veggies.database.toFloat
import com.example.veggies.getResourceFromString
import com.example.veggies.vendor.VendorActivity

class DeliveryActivity : AppCompatActivity() {
    companion object {
        private const val MODE_KEY = "mode_pref"
        private const val CUSTOMER_MODE = "customer"
        private const val VENDOR_MODE = "vendor"
        private const val SUPPLIER_MODE = "supplier"
    }

    private lateinit var sharedPref: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val database = VeggiesDatabase.getInstance(this)
        val viewModelFactory = DeliveryViewModelFactory(database)
        val viewModel = ViewModelProvider(this, viewModelFactory)[DeliveryViewModel::class.java]
        setContent {
            Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colors.background) {
                VeggiesTheme {
                    Delivery(viewModel = viewModel)
                }
            }
        }
        sharedPref = getSharedPreferences(packageName + "_preferences", Context.MODE_PRIVATE)
        sharedPref.registerOnSharedPreferenceChangeListener(sharedPreferenceChangeListener)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_customer_mode -> {
                with(sharedPref.edit()) {
                    putString(MODE_KEY, CUSTOMER_MODE)
                    apply()
                }
                true
            }
            R.id.action_vendor_mode -> {
                with(sharedPref.edit()) {
                    putString(MODE_KEY, VENDOR_MODE)
                    apply()
                }
                true
            }

            R.id.action_supplier_mode -> {
                // do nothing, already in supplier mode
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private val sharedPreferenceChangeListener =
        SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == MODE_KEY) {
                when (sharedPref.getString(MODE_KEY, SUPPLIER_MODE)) {
                    CUSTOMER_MODE -> {
                        val intent = Intent(this, CustomerActivity::class.java)
                        startActivity(intent)
                        finish()
                    }
                    VENDOR_MODE -> {
                        val intent = Intent(this, VendorActivity::class.java)
                        startActivity(intent)
                        finish()
                    }
                }
            }
        }
}

@Composable
fun Delivery(viewModel: DeliveryViewModel) {
    val orders = viewModel.orderItems.collectAsState(listOf())
    Surface(color = MaterialTheme.colors.background) {
        LazyColumn {
            items(orders.value) { order ->
                OrderItem(orderItem = order, viewModel = viewModel)
            }
        }
    }
}

@Composable
fun OrderItem(orderItem: OrderItem, viewModel: DeliveryViewModel) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Card(modifier = Modifier.padding(4.dp), elevation = 8.dp) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                ImageView(imageRes = getResourceFromString(orderItem.thumbnail), 150.dp)


                Column(modifier = Modifier.padding(horizontal = 8.dp)) {
                    Text(text = "Item : ${orderItem.name}", color = Color.Gray)
                    Text(text = "Ordered quantity : ${orderItem.quantity}", color = Color.Gray)

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(text = "Progress : ${orderItem.deliveryStatus.toString().lowercase()}", color = Color.Gray)
                    Row(modifier = Modifier.fillMaxWidth()) {
                        LinearProgressIndicator(
                            orderItem.deliveryStatus.toFloat(),
                            modifier = Modifier
                                .padding(vertical = 4.dp)
                                .height(6.dp)
                                .fillMaxWidth()
                                .clip(CircleShape), color = Color(0XFF319260)
                        )
                    }
                }
            }
        }

        Row(
            horizontalArrangement = Arrangement.End, modifier = Modifier
                .padding(4.dp)
                .fillMaxWidth()
        ) {
            OutlinedButton(
                onClick = { viewModel.updateDeliveryStatus(orderItem) },
            ) {
                Text(text = "Update progress", color = Color.Gray)
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = "Update delivery",
                    tint = Color(0XFF319260)
                )
            }
        }

        Divider(
            Modifier
                .height(0.5.dp)
                .fillMaxWidth(), color = Color.Gray
        )
    }
}


