package com.example.veggies.supplier

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.veggies.database.DeliveryStatus
import com.example.veggies.database.OrderItem
import com.example.veggies.database.VeggiesDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class DeliveryViewModel(val database: VeggiesDatabase) : ViewModel() {
    val orderItems: Flow<List<OrderItem>> = database.orderDao.getOrders()

    fun updateDeliveryStatus(orderItem: OrderItem) {
        viewModelScope.launch(Dispatchers.IO) {
            database.orderDao.updateDeliveryStatus(
                id = orderItem.id,
                ownerId = orderItem.owner_id,
                newDeliveryStatus = getNextDeliveryStatus(orderItem.deliveryStatus)
            )
        }

    }

    private fun getNextDeliveryStatus(currentStatus: DeliveryStatus): DeliveryStatus {
        return when (currentStatus) {
            DeliveryStatus.PENDING -> DeliveryStatus.DISPATCHED
            DeliveryStatus.DISPATCHED -> DeliveryStatus.INTRANS
            DeliveryStatus.INTRANS -> DeliveryStatus.DELIVERED
            DeliveryStatus.DELIVERED -> DeliveryStatus.DELIVERED
        }
    }
}

class DeliveryViewModelFactory(val database: VeggiesDatabase) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DeliveryViewModel::class.java)) {
            return DeliveryViewModel(database) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}