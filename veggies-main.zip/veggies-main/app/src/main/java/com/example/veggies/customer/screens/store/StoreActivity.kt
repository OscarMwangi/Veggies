package com.example.veggies.customer.screens.store

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.example.veggies.R
import com.example.veggies.customer.screens.store.model.StoreStockViewModel
import com.example.veggies.customer.screens.store.model.StoreStockViewModelFactory
import com.example.veggies.database.CartVegetable
import com.example.veggies.database.VeggiesDatabase
import com.example.veggies.databinding.ActivityStoreBinding
import com.example.veggies.toast

class StoreActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_STORE_ID: String = "store_id"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = DataBindingUtil.setContentView<ActivityStoreBinding>(this, R.layout.activity_store)
        val actionBar = supportActionBar
        with(actionBar) {
            this!!.setDisplayHomeAsUpEnabled(true)
            setDisplayShowHomeEnabled(true)
        }
        val database = VeggiesDatabase.getInstance(application)
        val storeId = intent.getLongExtra(EXTRA_STORE_ID, 0L)
        val storeStockViewModelFactory = StoreStockViewModelFactory(database, storeId, application)
        val storeStockViewModel = ViewModelProvider(this, storeStockViewModelFactory)[StoreStockViewModel::class.java]
        binding.storeStockViewModel = storeStockViewModel
        binding.lifecycleOwner = this
        val adapter = StoreStockAdapter(StocksListener {
            // call function from view model to add item to db
            toast("${it.name} added to cart")

            storeStockViewModel.addToCart(
                CartVegetable(
                    it.id,
                    it.owner_id,
                    it.name,
                    it.currency,
                    it.price,
                    1,
                    it.thumbnail
                )
            )
        })
        binding.vegetableList.adapter = adapter
        storeStockViewModel.stock.observe(this) { it?.let { adapter.submitList(it) } }
        storeStockViewModel.store.observe(this) { it?.let { title = it.name } }
        binding.lifecycleOwner = this
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}