package com.example.veggies.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow


@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(user: User): Long

    @Query("UPDATE users SET thumbnail =:url WHERE user_id =:key")
    suspend fun updateUserThumbnail(key: Long, url: String?)

    @Query("UPDATE users SET user_name =:name WHERE user_id =:key")
    suspend fun updateUserName(key: Long, name: String?)

    @Query("UPDATE users SET cart =:cart WHERE user_id =:key")
    suspend fun updateCart(key: Long, cart: Array<Long>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addToCart(vegetable: CartVegetable)

    @Query("UPDATE CART_VEGETABLES SET QUANTITY = :quantity WHERE owner_id = :ownerId and id = :id")
    suspend fun updateCartItem(id: Long, ownerId: Long, quantity: Long)

    @Query("SELECT * FROM users WHERE user_id =:key")
    fun getUser(key: Long): LiveData<User>

    @Query("SELECT * FROM users WHERE user_id =:key")
    fun getUserFlow(key: Long): Flow<User>

    @Query("SELECT * FROM cart_vegetables")
    fun getCartItems(): Flow<List<CartVegetable>>

    @Query("delete from cart_vegetables where owner_id =:ownerId and id =:id")
    suspend fun deleteCartItem(id: Long, ownerId: Long)

    @Query("delete from cart_vegetables")
    suspend fun deleteAllCartItems()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertToUserPurchaseHistory(item: PurchasedItem)

    @Query("SELECT * FROM purchase_items")
    fun getPurchaseHistory(): Flow<List<PurchasedItem>>
}