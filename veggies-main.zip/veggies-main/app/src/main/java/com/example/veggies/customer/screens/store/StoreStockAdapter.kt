package com.example.veggies.customer.screens.store

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.veggies.database.Vegetable
import com.example.veggies.databinding.StoreStockItemViewBinding

class StoreStockAdapter(private val clickListener: StocksListener) :
    ListAdapter<Vegetable, StoreStockAdapter.ViewHolder>(
        StocksDiffCallback()
    ) {

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position), clickListener)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder.from(parent)
    }

    class ViewHolder private constructor(private val binding: StoreStockItemViewBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: Vegetable, clickListener: StocksListener) {
            binding.vegetable = item
            binding.clickListener = clickListener
            binding.executePendingBindings()
        }

        companion object {
            fun from(parent: ViewGroup): ViewHolder {
                val layoutInflater = LayoutInflater.from(parent.context)
                val binding = StoreStockItemViewBinding.inflate(layoutInflater, parent, false)
                return ViewHolder(binding)
            }
        }
    }
}

class StocksDiffCallback : DiffUtil.ItemCallback<Vegetable>() {
    override fun areContentsTheSame(oldItem: Vegetable, newItem: Vegetable): Boolean {
        return oldItem == newItem
    }

    override fun areItemsTheSame(oldItem: Vegetable, newItem: Vegetable): Boolean {
        return oldItem.id == newItem.id
    }
}

class StocksListener(val clickListener: (id: Vegetable) -> Unit) {
    fun onClick(vegetable: Vegetable) = clickListener(vegetable)
}