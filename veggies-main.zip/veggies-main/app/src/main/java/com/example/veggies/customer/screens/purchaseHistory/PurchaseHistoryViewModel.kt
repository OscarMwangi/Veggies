package com.example.veggies.customer.screens.purchaseHistory

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.veggies.database.VeggiesDatabase

class PurchaseHistoryViewModel(database: VeggiesDatabase) : ViewModel() {
    val purchaseHistory = database.userDatabaseDao.getPurchaseHistory()
}

@Suppress("UNCHECKED_CAST")
class PurchaseHistoryViewModelFactory(private val database: VeggiesDatabase) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PurchaseHistoryViewModel::class.java)) {
            return PurchaseHistoryViewModel(database = database) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}