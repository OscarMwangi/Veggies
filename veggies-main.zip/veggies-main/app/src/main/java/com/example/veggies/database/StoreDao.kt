package com.example.veggies.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface StoreDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(store: Store): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(stores: List<Store>)

    @Query("SELECT * FROM stores WHERE id =:key")
    fun getStore(key: Long): LiveData<Store>

    @Query("SELECT * FROM stores ORDER BY id ASC")
    fun getAllStores(): LiveData<List<Store>>
}
